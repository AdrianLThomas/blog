﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelAggregator.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            const string WEBSITE_LOCATION = @"http://www.fuelly.com/car/";

            var htmlDocument = new HtmlAgilityPack.HtmlDocument();

            using (var webClient = new System.Net.WebClient())
            {
                using (var stream = webClient.OpenRead(WEBSITE_LOCATION))
                {
                    htmlDocument.Load(stream);
                }
            }

            HtmlAgilityPack.HtmlNodeCollection divTags = htmlDocument.DocumentNode.SelectNodes("//div[@id='inline-list']");

            HtmlAgilityPack.HtmlNode aTags = divTags.FirstOrDefault();
            var manufacturerList = from hyperlink in aTags.SelectNodes(".//a[@href]")
                                   where hyperlink != null
                                   select hyperlink.InnerText;

            foreach (var model in manufacturerList)
                Console.WriteLine(model);

            Console.ReadKey();
        }
    }
}
